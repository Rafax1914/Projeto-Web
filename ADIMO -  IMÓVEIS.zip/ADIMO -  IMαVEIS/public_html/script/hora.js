    var data = new Date();

    var hours = data.getHours();
    var minutes = data.getMinutes();
    var seconds = data.getSeconds();

    alert('Boa tarde! São exatamente: ' + hours + ':' + minutes + ':' + seconds);
